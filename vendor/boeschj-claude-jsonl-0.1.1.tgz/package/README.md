# @boeschj/claude-jsonl

A typed, drift-tolerant parser for **Claude Code session JSONL** — the transcript
files Claude Code writes under `~/.claude/projects`. One `TraceEntry` per line.

The on-disk schema is undocumented and shifts across CLI versions, so this
package is deliberately **total and non-throwing**: `parseTraceEntry` never
raises, no matter the shape you hand it — unrecognized entry types, subtypes,
and content blocks all narrow to `Unknown` (or an equivalent documented
default) instead. This is enforced by a hand-built fixture corpus covering
every entry and block variant (`test/`, run with `bun test`) and checked
against every real session file on the machine it was built on
(`scripts/validate-corpus.ts`; results in `test/CORPUS-RESULTS.md`). That
sweep also found that real corpora always contain some entry types this
model doesn't know yet — the CLI adds new ones between surveys — so "zero
unknown entry types" isn't a claim this package makes. What it does
guarantee: those unknown shapes degrade to `Unknown`, they never throw, and
every real-corpus throw or drop gets root-caused and fixed, not shrugged off.

It is the shared foundation for the tools that read those transcripts —
the parchment transcript viewer and the xray trace explorer both depend on it,
so the schema lives in exactly one place and stays in step with the format.

## Install

```bash
bun add @boeschj/claude-jsonl
```

## Use

```ts
import { parseTraceEntry, TraceEntryKind } from "@boeschj/claude-jsonl";

function isJsonObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

for (const line of jsonlText.split("\n").filter(Boolean)) {
  // parseTraceEntry itself never throws — but JSON.parse can, if a line was
  // truncated mid-write. Guard that boundary yourself, as shown here.
  let raw: unknown;
  try {
    raw = JSON.parse(line);
  } catch {
    continue;
  }
  if (!isJsonObject(raw)) continue;

  const entry = parseTraceEntry(raw);
  if (entry.kind === TraceEntryKind.Assistant) {
    // typed access to content blocks, token usage, model, etc.
  }
}
```

## Surface

- `parseTraceEntry(raw)` — one raw JSON object → a discriminated `TraceEntry`.
- `parseUsage(container)` — pull a normalized `TokenUsage` out of a message.
- The full entry schema: `TraceEntry` and its variants (assistant, user,
  system, attachment, file-history snapshot, queue-operation, PR-link,
  session-meta, unknown), plus the enums (`TraceEntryKind`, `BlockKind`,
  `SystemSubtype`, `UserOrigin`, `SessionMetaField`, …) and `TokenUsage`.

## Testing

```bash
bun test
```

`test/fixtures/*.jsonl` is a hand-built corpus covering every entry kind and
content-block shape this parser handles, plus deliberately malformed and
unrecognized shapes to prove they degrade instead of throwing. To re-check
the model against real sessions on your own machine:

```bash
bun run scripts/validate-corpus.ts
```

## License

MIT
