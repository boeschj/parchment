// Typed model of Claude Code session JSONL entries. One TraceEntry per line.
//
// The on-disk schema is undocumented and drifts across CLI versions, so this
// model is shaped by a corpus survey (2026-07-04, CLI 2.1.150–2.1.201, ~15,900
// entries across 50 sessions) rather than any spec. Unknown entry types and
// block types are preserved as Unknown variants — never dropped, never thrown.
//
// Every entry keeps a reference to its raw parsed line (`raw`) so downstream
// consumers can reach fields this model doesn't surface yet without reparsing.

export const TraceEntryKind = {
  Assistant: "assistant",
  User: "user",
  System: "system",
  Attachment: "attachment",
  FileHistorySnapshot: "file-history-snapshot",
  QueueOperation: "queue-operation",
  PrLink: "pr-link",
  SessionMeta: "session-meta",
  Unknown: "unknown",
} as const;

export type TraceEntryKind = (typeof TraceEntryKind)[keyof typeof TraceEntryKind];

// Envelope fields shared by conversational entries (user/assistant/system/
// attachment). Metadata-only lines (ai-title, pr-link, …) carry few of these.
export type TraceEnvelope = {
  // Metadata-only lines (ai-title, last-prompt, …) often have no uuid;
  // consumers needing a stable id fall back to file position.
  uuid: string | null;
  parentUuid: string | null;
  // Set on compaction boundaries: links to the pre-compaction message chain.
  logicalParentUuid: string | null;
  timestamp: string | null;
  timestampMs: number | null;
  // The session this file belongs to. `lineageSessionId` (raw `session_id`)
  // can differ from `sessionId` — it tracks the originating session across
  // forks/resumes, which is what makes cross-session graphs possible.
  sessionId: string | null;
  lineageSessionId: string | null;
  // Groups every entry produced by one user turn.
  promptId: string | null;
  agentId: string | null;
  isSidechain: boolean;
  cwd: string | null;
  gitBranch: string | null;
  version: string | null;
  slug: string | null;
};

export const UserOrigin = {
  Human: "human",
  TaskNotification: "task-notification",
  // Messages exchanged between a subagent and the coordinator/peer agents
  // that spawned it (isSidechain: true, agentId set).
  Coordinator: "coordinator",
  Peer: "peer",
  Synthetic: "synthetic",
} as const;

export type UserOrigin = (typeof UserOrigin)[keyof typeof UserOrigin];

// How a tool call came to be refused, when it was.
export const ToolDenialKind = {
  PermissionRule: "permission-rule",
  AutomodeBlocked: "automode-blocked",
  UserRejected: "user-rejected",
  AutomodeUnavailable: "automode-unavailable",
} as const;

export type ToolDenialKind = (typeof ToolDenialKind)[keyof typeof ToolDenialKind];

// ---------------------------------------------------------------------------
// Content blocks
// ---------------------------------------------------------------------------

export const BlockKind = {
  Text: "text",
  Thinking: "thinking",
  RedactedThinking: "redacted-thinking",
  ToolUse: "tool-use",
  Image: "image",
  ModelFallback: "model-fallback",
  Unknown: "unknown",
} as const;

export type BlockKind = (typeof BlockKind)[keyof typeof BlockKind];

export type ContentBlock =
  | { kind: typeof BlockKind.Text; text: string }
  | { kind: typeof BlockKind.Thinking; text: string }
  | { kind: typeof BlockKind.RedactedThinking }
  | {
      kind: typeof BlockKind.ToolUse;
      toolUseId: string;
      toolName: string;
      input: Record<string, unknown>;
    }
  | { kind: typeof BlockKind.Image; dataUrl: string }
  | { kind: typeof BlockKind.ModelFallback; fromModel: string | null; toModel: string | null }
  | { kind: typeof BlockKind.Unknown; rawType: string };

// A tool_result block from a user entry, already flattened to what renderers
// and analyzers consume.
export type ToolResultBlock = {
  toolUseId: string;
  text: string;
  images: string[];
  isError: boolean;
};

// ---------------------------------------------------------------------------
// Token usage
// ---------------------------------------------------------------------------

export type TokenUsage = {
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  cacheCreationTokens: number;
  // Cache writes split by TTL tier — they're priced differently.
  cacheCreation5mTokens: number;
  cacheCreation1hTokens: number;
  webSearchRequests: number;
  webFetchRequests: number;
  serviceTier: string | null;
};

// ---------------------------------------------------------------------------
// Entry variants
// ---------------------------------------------------------------------------

export type AssistantTraceEntry = {
  kind: typeof TraceEntryKind.Assistant;
  envelope: TraceEnvelope;
  model: string;
  // Anthropic message id. Multiple JSONL lines share one messageId (one line
  // per content block); usage MUST be deduped by messageId before summing.
  messageId: string | null;
  requestId: string | null;
  stopReason: string | null;
  usage: TokenUsage | null;
  blocks: ContentBlock[];
  // model === "<synthetic>" marks locally fabricated error messages.
  isSynthetic: boolean;
  apiErrorMessage: string | null;
  raw: Record<string, unknown>;
};

export type UserTraceEntry = {
  kind: typeof TraceEntryKind.User;
  envelope: TraceEnvelope;
  origin: UserOrigin;
  promptSource: string | null;
  isMeta: boolean;
  // Present on the synthetic continuation message written after compaction.
  isCompactSummary: boolean;
  text: string;
  images: string[];
  toolResults: ToolResultBlock[];
  // The rich per-tool result payload (Edit's structuredPatch, Bash's stdout,
  // Task's usage rollup, an array of content parts for multi-part tool
  // outputs, …). A plain string when the tool was denied.
  toolUseResult: Record<string, unknown> | Record<string, unknown>[] | string | null;
  toolDenialKind: ToolDenialKind | null;
  sourceToolUseId: string | null;
  sourceToolAssistantUuid: string | null;
  raw: Record<string, unknown>;
};

export const SystemSubtype = {
  TurnDuration: "turn_duration",
  ApiError: "api_error",
  CompactBoundary: "compact_boundary",
  StopHookSummary: "stop_hook_summary",
  ModelRefusalFallback: "model_refusal_fallback",
  AwaySummary: "away_summary",
  LocalCommand: "local_command",
  ScheduledTaskFire: "scheduled_task_fire",
  Informational: "informational",
} as const;

export type SystemSubtype = (typeof SystemSubtype)[keyof typeof SystemSubtype];

export type CompactionMetadata = {
  trigger: string | null;
  preTokens: number | null;
  postTokens: number | null;
  cumulativeDroppedTokens: number | null;
  durationMs: number | null;
  preservedMessageUuids: string[];
};

export type StopHookInfo = {
  command: string | null;
  durationMs: number | null;
};

export type SystemPayload =
  | { subtype: typeof SystemSubtype.TurnDuration; durationMs: number | null; messageCount: number | null }
  | {
      subtype: typeof SystemSubtype.ApiError;
      message: string | null;
      retryInMs: number | null;
      retryAttempt: number | null;
      maxRetries: number | null;
    }
  | { subtype: typeof SystemSubtype.CompactBoundary; compaction: CompactionMetadata }
  | {
      subtype: typeof SystemSubtype.StopHookSummary;
      hookCount: number | null;
      // Raw per-hook failure entries. Shape is unconfirmed against a
      // populated real-world sample, so this stays unprocessed rather than
      // guessing a structure.
      hookErrors: unknown[];
      preventedContinuation: boolean;
      stopReason: string | null;
      hooks: StopHookInfo[];
    }
  | {
      subtype: typeof SystemSubtype.ModelRefusalFallback;
      originalModel: string | null;
      fallbackModel: string | null;
      trigger: string | null;
      refusalCategory: string | null;
    }
  | { subtype: typeof SystemSubtype.AwaySummary; content: string }
  | { subtype: typeof SystemSubtype.LocalCommand; content: string }
  | { subtype: typeof SystemSubtype.ScheduledTaskFire; content: string }
  | { subtype: typeof SystemSubtype.Informational; content: string }
  | { subtype: "unknown"; rawSubtype: string; content: string };

export type SystemTraceEntry = {
  kind: typeof TraceEntryKind.System;
  envelope: TraceEnvelope;
  payload: SystemPayload;
  raw: Record<string, unknown>;
};

// Injected-context lines (task reminders, hook output, skill listings, …).
// Subtypes churn across versions, so the payload stays raw; hook_success is
// common and analytically useful enough to get typed fields.
export type AttachmentTraceEntry = {
  kind: typeof TraceEntryKind.Attachment;
  envelope: TraceEnvelope;
  subtype: string;
  hook: { hookName: string | null; hookEvent: string | null; exitCode: number | null; command: string | null } | null;
  attachment: Record<string, unknown>;
  raw: Record<string, unknown>;
};

export type FileHistorySnapshotTraceEntry = {
  kind: typeof TraceEntryKind.FileHistorySnapshot;
  envelope: TraceEnvelope;
  messageId: string | null;
  trackedFilePaths: string[];
  isSnapshotUpdate: boolean;
  raw: Record<string, unknown>;
};

export type QueueOperationTraceEntry = {
  kind: typeof TraceEntryKind.QueueOperation;
  envelope: TraceEnvelope;
  operation: string;
  content: string;
  raw: Record<string, unknown>;
};

export type PrLinkTraceEntry = {
  kind: typeof TraceEntryKind.PrLink;
  envelope: TraceEnvelope;
  prNumber: number | null;
  prUrl: string | null;
  prRepository: string | null;
  raw: Record<string, unknown>;
};

// Single-field session state lines, rewritten as the session evolves.
export const SessionMetaField = {
  AiTitle: "ai-title",
  CustomTitle: "custom-title",
  LastPrompt: "last-prompt",
  PermissionMode: "permission-mode",
  Mode: "mode",
  AgentName: "agent-name",
  AgentSetting: "agent-setting",
  BridgeSession: "bridge-session",
} as const;

export type SessionMetaField = (typeof SessionMetaField)[keyof typeof SessionMetaField];

export type SessionMetaTraceEntry = {
  kind: typeof TraceEntryKind.SessionMeta;
  envelope: TraceEnvelope;
  field: SessionMetaField;
  value: string;
  raw: Record<string, unknown>;
};

export type UnknownTraceEntry = {
  kind: typeof TraceEntryKind.Unknown;
  envelope: TraceEnvelope;
  rawType: string;
  raw: Record<string, unknown>;
};

export type TraceEntry =
  | AssistantTraceEntry
  | UserTraceEntry
  | SystemTraceEntry
  | AttachmentTraceEntry
  | FileHistorySnapshotTraceEntry
  | QueueOperationTraceEntry
  | PrLinkTraceEntry
  | SessionMetaTraceEntry
  | UnknownTraceEntry;
