// Raw JSONL line → TraceEntry. Pure, total, no I/O: unknown shapes narrow to
// Unknown variants instead of throwing, so schema drift degrades gracefully.

import {
  arrayField,
  booleanField,
  isRecord,
  numberField,
  recordField,
  recordItems,
  stringField,
  stringItems,
} from "./narrow.ts";
import type {
  AssistantTraceEntry,
  AttachmentTraceEntry,
  CompactionMetadata,
  ContentBlock,
  FileHistorySnapshotTraceEntry,
  PrLinkTraceEntry,
  QueueOperationTraceEntry,
  SessionMetaTraceEntry,
  StopHookInfo,
  SystemPayload,
  SystemTraceEntry,
  TokenUsage,
  ToolDenialKind,
  ToolResultBlock,
  TraceEntry,
  TraceEnvelope,
  UserOrigin as UserOriginType,
  UserTraceEntry,
} from "./entry-types.ts";
import { BlockKind, SessionMetaField, SystemSubtype, TraceEntryKind, UserOrigin } from "./entry-types.ts";

const SESSION_META_VALUE_KEYS: Record<SessionMetaField, string> = {
  [SessionMetaField.AiTitle]: "aiTitle",
  [SessionMetaField.CustomTitle]: "customTitle",
  // On disk this carries the uuid of the session's last message, not prompt
  // text — the raw key is "leafUuid", never "lastPrompt".
  [SessionMetaField.LastPrompt]: "leafUuid",
  [SessionMetaField.PermissionMode]: "permissionMode",
  [SessionMetaField.Mode]: "mode",
  [SessionMetaField.AgentName]: "agentName",
  [SessionMetaField.AgentSetting]: "agentSetting",
  [SessionMetaField.BridgeSession]: "bridgeSessionId",
};

const SESSION_META_FIELDS = new Set<string>(Object.values(SessionMetaField));

const KNOWN_SYSTEM_SUBTYPES = new Set<string>(Object.values(SystemSubtype));

const KNOWN_DENIAL_KINDS = new Set<string>([
  "permission-rule",
  "automode-blocked",
  "user-rejected",
  "automode-unavailable",
]);

// User entries with no origin field but content starting with these tags are
// injected by the harness, not typed by a human.
const SYNTHETIC_USER_PREFIXES = [
  "<task-notification>",
  "<command-name>",
  "<local-command-stdout>",
  "<local-command-stderr>",
  "<system-reminder>",
] as const;

export function parseTraceEntry(raw: Record<string, unknown>): TraceEntry {
  const rawType = stringField(raw, "type") ?? "";
  const envelope = parseEnvelope(raw);

  if (rawType === "assistant") return parseAssistant(raw, envelope);
  if (rawType === "user") return parseUser(raw, envelope);
  if (rawType === "system") return parseSystem(raw, envelope);
  if (rawType === "attachment") return parseAttachment(raw, envelope);
  if (rawType === "file-history-snapshot") return parseFileHistorySnapshot(raw, envelope);
  if (rawType === "queue-operation") return parseQueueOperation(raw, envelope);
  if (rawType === "pr-link") return parsePrLink(raw, envelope);
  if (SESSION_META_FIELDS.has(rawType)) {
    return parseSessionMeta(raw, envelope, rawType as SessionMetaField);
  }

  return { kind: TraceEntryKind.Unknown, envelope, rawType, raw };
}

// ---------------------------------------------------------------------------
// Envelope
// ---------------------------------------------------------------------------

function parseEnvelope(raw: Record<string, unknown>): TraceEnvelope {
  const timestamp = stringField(raw, "timestamp");
  const parsedMs = timestamp === null ? Number.NaN : Date.parse(timestamp);

  return {
    uuid: stringField(raw, "uuid"),
    parentUuid: stringField(raw, "parentUuid"),
    logicalParentUuid: stringField(raw, "logicalParentUuid"),
    timestamp,
    timestampMs: Number.isNaN(parsedMs) ? null : parsedMs,
    sessionId: stringField(raw, "sessionId"),
    lineageSessionId: stringField(raw, "session_id"),
    promptId: stringField(raw, "promptId"),
    agentId: stringField(raw, "agentId"),
    isSidechain: booleanField(raw, "isSidechain") ?? false,
    cwd: stringField(raw, "cwd"),
    gitBranch: stringField(raw, "gitBranch"),
    version: stringField(raw, "version"),
    slug: stringField(raw, "slug"),
  };
}

// ---------------------------------------------------------------------------
// Assistant
// ---------------------------------------------------------------------------

function parseAssistant(raw: Record<string, unknown>, envelope: TraceEnvelope): AssistantTraceEntry {
  const message = recordField(raw, "message");
  const model = stringField(message, "model") ?? "unknown";

  return {
    kind: TraceEntryKind.Assistant,
    envelope,
    model,
    messageId: stringField(message, "id"),
    requestId: stringField(raw, "requestId"),
    stopReason: stringField(message, "stop_reason"),
    usage: parseUsage(message),
    blocks: recordItems(arrayField(message, "content")).map(parseContentBlock),
    isSynthetic: model === "<synthetic>",
    apiErrorMessage: stringField(raw, "apiErrorMessage"),
    raw,
  };
}

// Reads a raw API-shaped `usage` object off `container`. Exported because the
// same shape appears in Task tool results (subagent usage rollups), not just
// assistant messages.
export function parseUsage(container: Record<string, unknown>): TokenUsage | null {
  const usage = container["usage"];
  if (!isRecord(usage)) return null;

  const cacheCreationDetail = recordField(usage, "cache_creation");
  const serverToolUse = recordField(usage, "server_tool_use");

  return {
    inputTokens: numberField(usage, "input_tokens") ?? 0,
    outputTokens: numberField(usage, "output_tokens") ?? 0,
    cacheReadTokens: numberField(usage, "cache_read_input_tokens") ?? 0,
    cacheCreationTokens: numberField(usage, "cache_creation_input_tokens") ?? 0,
    cacheCreation5mTokens: numberField(cacheCreationDetail, "ephemeral_5m_input_tokens") ?? 0,
    cacheCreation1hTokens: numberField(cacheCreationDetail, "ephemeral_1h_input_tokens") ?? 0,
    webSearchRequests: numberField(serverToolUse, "web_search_requests") ?? 0,
    webFetchRequests: numberField(serverToolUse, "web_fetch_requests") ?? 0,
    serviceTier: stringField(usage, "service_tier"),
  };
}

function parseContentBlock(block: Record<string, unknown>): ContentBlock {
  const blockType = stringField(block, "type") ?? "";

  if (blockType === "text") {
    return { kind: BlockKind.Text, text: stringField(block, "text") ?? "" };
  }
  if (blockType === "thinking") {
    return { kind: BlockKind.Thinking, text: stringField(block, "thinking") ?? "" };
  }
  if (blockType === "redacted_thinking") {
    return { kind: BlockKind.RedactedThinking };
  }
  if (blockType === "tool_use") {
    return {
      kind: BlockKind.ToolUse,
      toolUseId: stringField(block, "id") ?? "",
      toolName: stringField(block, "name") ?? "unknown",
      input: recordField(block, "input"),
    };
  }
  if (blockType === "image") {
    const dataUrl = imageDataUrl(block);
    if (dataUrl !== null) return { kind: BlockKind.Image, dataUrl };
  }
  if (blockType === "fallback") {
    return {
      kind: BlockKind.ModelFallback,
      fromModel: stringField(recordField(block, "from"), "model"),
      toModel: stringField(recordField(block, "to"), "model"),
    };
  }

  return { kind: BlockKind.Unknown, rawType: blockType };
}

// ---------------------------------------------------------------------------
// User
// ---------------------------------------------------------------------------

function parseUser(raw: Record<string, unknown>, envelope: TraceEnvelope): UserTraceEntry {
  const message = recordField(raw, "message");
  const content = message["content"];

  const textParts: string[] = [];
  const images: string[] = [];
  const toolResults: ToolResultBlock[] = [];

  if (typeof content === "string") {
    textParts.push(content);
  }
  if (Array.isArray(content)) {
    for (const block of recordItems(content)) {
      collectUserBlock(block, textParts, images, toolResults);
    }
  }

  const text = textParts.join("\n\n");

  return {
    kind: TraceEntryKind.User,
    envelope,
    origin: parseUserOrigin(raw, text),
    promptSource: stringField(raw, "promptSource"),
    isMeta: booleanField(raw, "isMeta") ?? false,
    isCompactSummary: booleanField(raw, "isCompactSummary") ?? false,
    text,
    images,
    toolResults,
    toolUseResult: parseToolUseResult(raw),
    toolDenialKind: parseDenialKind(raw),
    sourceToolUseId: stringField(raw, "sourceToolUseID"),
    sourceToolAssistantUuid: stringField(raw, "sourceToolAssistantUUID"),
    raw,
  };
}

function collectUserBlock(
  block: Record<string, unknown>,
  textParts: string[],
  images: string[],
  toolResults: ToolResultBlock[],
): void {
  const blockType = stringField(block, "type");

  if (blockType === "text") {
    const text = stringField(block, "text");
    if (text !== null && text.length > 0) textParts.push(text);
  }
  if (blockType === "image") {
    const dataUrl = imageDataUrl(block);
    if (dataUrl !== null) images.push(dataUrl);
  }
  if (blockType === "tool_result") {
    const toolUseId = stringField(block, "tool_use_id");
    if (toolUseId !== null) {
      toolResults.push({
        toolUseId,
        text: toolResultText(block["content"]),
        images: toolResultImages(block["content"]),
        isError: block["is_error"] === true,
      });
    }
  }
}

function parseUserOrigin(raw: Record<string, unknown>, text: string): UserOriginType {
  const originKind = stringField(recordField(raw, "origin"), "kind");
  if (originKind === UserOrigin.Human) return UserOrigin.Human;
  if (originKind === UserOrigin.TaskNotification) return UserOrigin.TaskNotification;
  if (originKind === UserOrigin.Coordinator) return UserOrigin.Coordinator;
  if (originKind === UserOrigin.Peer) return UserOrigin.Peer;
  if (originKind !== null) return UserOrigin.Synthetic;

  // Old lines lack origin entirely; injected content betrays itself by prefix.
  const trimmed = text.trimStart();
  const isSynthetic = SYNTHETIC_USER_PREFIXES.some((prefix) => trimmed.startsWith(prefix));
  return isSynthetic ? UserOrigin.Synthetic : UserOrigin.Human;
}

function parseToolUseResult(
  raw: Record<string, unknown>,
): Record<string, unknown> | Record<string, unknown>[] | string | null {
  const value = raw["toolUseResult"];
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return recordItems(value);
  if (isRecord(value)) return value;
  return null;
}

function parseDenialKind(raw: Record<string, unknown>): ToolDenialKind | null {
  const value = stringField(raw, "toolDenialKind");
  if (value === null) return null;
  return KNOWN_DENIAL_KINDS.has(value) ? (value as ToolDenialKind) : null;
}

// ---------------------------------------------------------------------------
// System
// ---------------------------------------------------------------------------

function parseSystem(raw: Record<string, unknown>, envelope: TraceEnvelope): SystemTraceEntry {
  return { kind: TraceEntryKind.System, envelope, payload: parseSystemPayload(raw), raw };
}

function parseSystemPayload(raw: Record<string, unknown>): SystemPayload {
  const subtype = stringField(raw, "subtype") ?? "";
  const content = stringField(raw, "content") ?? "";

  if (subtype === SystemSubtype.TurnDuration) {
    return {
      subtype,
      durationMs: numberField(raw, "durationMs"),
      messageCount: numberField(raw, "messageCount"),
    };
  }
  if (subtype === SystemSubtype.ApiError) {
    return {
      subtype,
      message: stringField(recordField(raw, "error"), "message"),
      retryInMs: numberField(raw, "retryInMs"),
      retryAttempt: numberField(raw, "retryAttempt"),
      maxRetries: numberField(raw, "maxRetries"),
    };
  }
  if (subtype === SystemSubtype.CompactBoundary) {
    return { subtype, compaction: parseCompactionMetadata(recordField(raw, "compactMetadata")) };
  }
  if (subtype === SystemSubtype.StopHookSummary) {
    return {
      subtype,
      hookCount: numberField(raw, "hookCount"),
      hookErrors: arrayField(raw, "hookErrors"),
      preventedContinuation: booleanField(raw, "preventedContinuation") ?? false,
      stopReason: stringField(raw, "stopReason"),
      hooks: recordItems(arrayField(raw, "hookInfos")).map(parseStopHookInfo),
    };
  }
  if (subtype === SystemSubtype.ModelRefusalFallback) {
    return {
      subtype,
      originalModel: stringField(raw, "originalModel"),
      fallbackModel: stringField(raw, "fallbackModel"),
      trigger: stringField(raw, "trigger"),
      refusalCategory: stringField(raw, "apiRefusalCategory"),
    };
  }
  if (
    subtype === SystemSubtype.AwaySummary ||
    subtype === SystemSubtype.LocalCommand ||
    subtype === SystemSubtype.ScheduledTaskFire ||
    subtype === SystemSubtype.Informational
  ) {
    return { subtype, content };
  }

  return { subtype: "unknown", rawSubtype: subtype, content };
}

function parseCompactionMetadata(metadata: Record<string, unknown>): CompactionMetadata {
  const preserved = recordField(metadata, "preservedMessages");

  return {
    trigger: stringField(metadata, "trigger"),
    preTokens: numberField(metadata, "preTokens"),
    postTokens: numberField(metadata, "postTokens"),
    cumulativeDroppedTokens: numberField(metadata, "cumulativeDroppedTokens"),
    durationMs: numberField(metadata, "durationMs"),
    preservedMessageUuids: stringItems(arrayField(preserved, "uuids")),
  };
}

function parseStopHookInfo(info: Record<string, unknown>): StopHookInfo {
  return {
    command: stringField(info, "command"),
    durationMs: numberField(info, "durationMs"),
  };
}

// ---------------------------------------------------------------------------
// Attachment / snapshot / queue / pr-link / session-meta
// ---------------------------------------------------------------------------

function parseAttachment(raw: Record<string, unknown>, envelope: TraceEnvelope): AttachmentTraceEntry {
  const attachment = recordField(raw, "attachment");
  const subtype = stringField(attachment, "type") ?? "unknown";

  const hook =
    subtype === "hook_success"
      ? {
          hookName: stringField(attachment, "hookName"),
          hookEvent: stringField(attachment, "hookEvent"),
          exitCode: numberField(attachment, "exitCode"),
          command: stringField(attachment, "command"),
        }
      : null;

  return { kind: TraceEntryKind.Attachment, envelope, subtype, hook, attachment, raw };
}

function parseFileHistorySnapshot(
  raw: Record<string, unknown>,
  envelope: TraceEnvelope,
): FileHistorySnapshotTraceEntry {
  const snapshot = recordField(raw, "snapshot");

  return {
    kind: TraceEntryKind.FileHistorySnapshot,
    envelope,
    messageId: stringField(raw, "messageId") ?? stringField(snapshot, "messageId"),
    trackedFilePaths: Object.keys(recordField(snapshot, "trackedFileBackups")),
    isSnapshotUpdate: booleanField(raw, "isSnapshotUpdate") ?? false,
    raw,
  };
}

function parseQueueOperation(raw: Record<string, unknown>, envelope: TraceEnvelope): QueueOperationTraceEntry {
  return {
    kind: TraceEntryKind.QueueOperation,
    envelope,
    operation: stringField(raw, "operation") ?? "unknown",
    content: stringField(raw, "content") ?? "",
    raw,
  };
}

function parsePrLink(raw: Record<string, unknown>, envelope: TraceEnvelope): PrLinkTraceEntry {
  return {
    kind: TraceEntryKind.PrLink,
    envelope,
    prNumber: numberField(raw, "prNumber"),
    prUrl: stringField(raw, "prUrl"),
    prRepository: stringField(raw, "prRepository"),
    raw,
  };
}

function parseSessionMeta(
  raw: Record<string, unknown>,
  envelope: TraceEnvelope,
  field: SessionMetaField,
): SessionMetaTraceEntry {
  const valueKey = SESSION_META_VALUE_KEYS[field];
  const value = stringField(raw, valueKey) ?? "";

  return { kind: TraceEntryKind.SessionMeta, envelope, field, value, raw };
}

// ---------------------------------------------------------------------------
// Shared block helpers
// ---------------------------------------------------------------------------

function imageDataUrl(block: Record<string, unknown>): string | null {
  const source = recordField(block, "source");
  const sourceType = stringField(source, "type");
  if (sourceType === "url") return stringField(source, "url");
  if (sourceType !== "base64") return null;

  const data = stringField(source, "data");
  if (data === null) return null;

  const mediaType = stringField(source, "media_type") ?? "image/png";
  return `data:${mediaType};base64,${data}`;
}

function toolResultText(content: unknown): string {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";

  const parts: string[] = [];
  for (const part of recordItems(content)) {
    if (part["type"] !== "text") continue;
    const text = stringField(part, "text");
    if (text !== null) parts.push(text);
  }
  return parts.join("\n");
}

function toolResultImages(content: unknown): string[] {
  if (!Array.isArray(content)) return [];

  const urls: string[] = [];
  for (const part of recordItems(content)) {
    if (part["type"] !== "image") continue;
    const url = imageDataUrl(part);
    if (url !== null) urls.push(url);
  }
  return urls;
}
