// Public surface of @boeschj/claude-jsonl: the typed Claude Code session
// JSONL schema plus the pure line parser. Internal narrowing helpers
// (narrow.ts) stay private — consumers work in terms of TraceEntry.

export * from "./entry-types.ts";
export * from "./parse-entry.ts";
