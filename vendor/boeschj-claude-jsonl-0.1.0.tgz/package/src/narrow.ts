// Defensive narrowing helpers for undocumented JSON shapes. The Claude Code
// JSONL schema drifts across versions, so every read is total: wrong shapes
// yield null/empty instead of throwing.

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function stringField(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  return typeof value === "string" ? value : null;
}

export function numberField(record: Record<string, unknown>, key: string): number | null {
  const value = record[key];
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

export function booleanField(record: Record<string, unknown>, key: string): boolean | null {
  const value = record[key];
  return typeof value === "boolean" ? value : null;
}

export function recordField(record: Record<string, unknown>, key: string): Record<string, unknown> {
  const value = record[key];
  return isRecord(value) ? value : {};
}

export function arrayField(record: Record<string, unknown>, key: string): unknown[] {
  const value = record[key];
  return Array.isArray(value) ? value : [];
}

export function recordItems(values: unknown[]): Record<string, unknown>[] {
  return values.filter(isRecord);
}

export function stringItems(values: unknown[]): string[] {
  return values.filter((value): value is string => typeof value === "string");
}
