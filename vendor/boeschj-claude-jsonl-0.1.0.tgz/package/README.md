# @boeschj/claude-jsonl

A typed, drift-tolerant parser for **Claude Code session JSONL** — the transcript
files Claude Code writes under `~/.claude/projects`. One `TraceEntry` per line.

The on-disk schema is undocumented and shifts across CLI versions, so this
package is deliberately **total and non-throwing**: unknown shapes narrow to
`Unknown` variants rather than raising, and the model was validated against a
real corpus with zero unrecognized entry types.

It is the shared foundation for the tools that read those transcripts —
the parchment transcript viewer and the xray trace explorer both depend on it,
so the schema lives in exactly one place and stays in step with the format.

## Install

```bash
bun add @boeschj/claude-jsonl
```

## Use

```ts
import { parseTraceEntry, TraceEntryKind } from "@boeschj/claude-jsonl";

for (const line of jsonlText.split("\n").filter(Boolean)) {
  const entry = parseTraceEntry(JSON.parse(line));
  if (entry.kind === TraceEntryKind.Assistant) {
    // typed access to content blocks, token usage, model, etc.
  }
}
```

## Surface

- `parseTraceEntry(raw)` — one raw JSON object → a discriminated `TraceEntry`.
- `parseUsage(container)` — pull a normalized `TokenUsage` out of a message.
- The full entry schema: `TraceEntry` and its variants (assistant, user,
  system, attachment, file-history snapshot, queue-operation, PR-link,
  session-meta, unknown), plus the enums (`TraceEntryKind`, `BlockKind`,
  `SystemSubtype`, `UserOrigin`, `SessionMetaField`, …) and `TokenUsage`.

## License

MIT
